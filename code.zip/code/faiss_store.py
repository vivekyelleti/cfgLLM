import os
import re
import faiss
import numpy as np
from sentence_transformers import SentenceTransformer

# Initialize the SentenceTransformer model
embed_model = SentenceTransformer("all-MiniLM-L6-v2")

# Folder where the DOT graphs are stored
dot_folder = "database/static"

# Initialize FAISS index
d = 384  # Embedding dimension for "all-MiniLM-L6-v2" model
index = faiss.IndexFlatL2(d)  # Use L2 distance for similarity search

# List to hold embeddings and corresponding file names
embeddings = []
file_names = []

# Function to read DOT file content
def read_dot_file(file_path):
    with open(file_path, "r") as f:
        return f.read()

# Process each DOT graph in the database folder
for file_name in os.listdir(dot_folder):
    if file_name.endswith(".dot"):  # Only process .dot files
        file_path = os.path.join(dot_folder, file_name)
        
        # Read DOT graph content
        dot_content = read_dot_file(file_path)
        
        # Generate embedding for the DOT graph (using its content as a string)
        embedding = embed_model.encode([dot_content])[0]  # Embedding for the file's content
        
        # Store embedding and file name (or any relevant identifier)
        embeddings.append(embedding)
        file_names.append(file_name)

# Convert embeddings to numpy array
embeddings = np.array(embeddings).astype("float32")

# Add embeddings to the FAISS index
index.add(embeddings)

# Save the FAISS index to disk
faiss.write_index(index, "database/faiss_dot.index")

print(f"Generated embeddings for {len(file_names)} DOT files and saved to FAISS index.")
