import os
import re
import pickle
import faiss
import numpy as np
import networkx as nx
import pydot
import logging
from flask import Flask, render_template, request, url_for
from dotenv import load_dotenv
from openai import OpenAI
from groq import Groq
import google.generativeai as genai
from sentence_transformers import SentenceTransformer

# Set up logging
logging.basicConfig(level=logging.INFO, filename='logs/app.log', format='%(asctime)s - %(message)s')

# Load API keys
load_dotenv()

# API clients
client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
groq_client = Groq(api_key=os.getenv("GROQ_API_KEY"))
genai.configure(api_key=os.getenv("GEMINI_API_KEY"))
gemini_model = genai.GenerativeModel("gemini-2.0-flash")

# Initialize Flask
app = Flask(__name__)

# Embedding model and FAISS setup
embed_model = SentenceTransformer("all-MiniLM-L6-v2")
FAISS_INDEX_PATH = "database/faiss_dot.index"
DOT_TEXTS_PATH = "./cfg_graph.dot"

if os.path.exists(FAISS_INDEX_PATH) and os.path.exists(DOT_TEXTS_PATH):
    faiss_index = faiss.read_index(FAISS_INDEX_PATH)
    with open(DOT_TEXTS_PATH, "rb") as f:
        dot_texts = pickle.load(f)
else:
    faiss_index = faiss.IndexFlatL2(384)
    dot_texts = []

# --- Utility Functions ---
def extract_section(text, label):
    match = re.search(fr"{label}:(.*?)(?=\n[A-Z]+:|$)", text, re.DOTALL)
    return match.group(1).strip() if match else "Not Found"

def extract_dot_code(text):
    try:
        start_index = text.index("digraph")
        end_index = text.rindex("}") + 1
        return text[start_index:end_index]
    except ValueError:
        return ""

def fix_invalid_dot_edges(dot_code):
    fixed_lines = []
    for line in dot_code.splitlines():
        match = re.match(r'\s*(\w+)\s*->\|([^|]+)\|\s*(\w+)', line)
        if match:
            src, label, dst = match.groups()
            fixed_lines.append(f'{src} -> {dst} [label="{label.strip()}"];')
        else:
            fixed_lines.append(line)
    return "\n".join(fixed_lines)

def calculate_cyclomatic_complexity(dot_code):
    dot_code = fix_invalid_dot_edges(dot_code)
    with open("cfg_graph.dot", "w") as f:
        f.write(dot_code)
    (graph,) = pydot.graph_from_dot_file("cfg_graph.dot")
    nx_graph = nx.drawing.nx_pydot.from_pydot(graph)
    num_nodes = nx_graph.number_of_nodes()
    num_edges = nx_graph.number_of_edges()
    complexity = num_edges - num_nodes + 2
    return {
        'Number of Nodes': num_nodes,
        'Number of Edges': num_edges,
        'Cyclomatic Complexity': complexity
    }

def store_dot_in_faiss(dot_code):
    global faiss_index, dot_texts
    logging.info("Storing DOT code in FAISS index")  # Log when storing
    embedding = embed_model.encode([dot_code]).astype("float32")
    faiss_index.add(embedding)
    dot_texts.append(dot_code)
    faiss.write_index(faiss_index, FAISS_INDEX_PATH)
    with open(DOT_TEXTS_PATH, "wb") as f:
        pickle.dump(dot_texts, f)
    logging.info(f"Stored DOT code with embedding. Total DOTs in database: {len(dot_texts)}")

def search_similar_dot(query_text, k=3):
    logging.info(f"Retrieving similar DOT code for query: {query_text[:30]}...")  # Log when retrieval happens
    query_embedding = embed_model.encode([query_text]).astype("float32")
    D, I = faiss_index.search(query_embedding, k)
    similar_dots = [dot_texts[i] for i in I[0] if i < len(dot_texts)]
    logging.info(f"Found {len(similar_dots)} similar DOTs")  # Log the number of similar DOTs found
    return similar_dots

# --- LLM Integration ---
def fetch_llm_response(llm, user_input):
    input_prompt = (
        "You are a control flow graph generator (start and end nodes required).\n"
        "Step 1: Extract functionalities.\n"
        "Step 2: Identify events.\n"
        "Step 3: Identify decisions.\n"
        "Step 4: Generate a DOT format control flow graph.\n\n"
        "OUTPUT FORMAT:\n"
        "FUNCTIONALITIES: ...\n"
        "EVENTS: ...\n"
        "DECISIONS: ...\n"
        "DOT:\n"
        "digraph G {\n"
        "// CFG here\n"
        "}\n\n"
        f"Scenario: {user_input}"
    )

    if llm == "openai":
        response = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[{"role": "user", "content": input_prompt}]
        )
        content = response.choices[0].message.content.strip()

    elif llm == "groq":
        response = groq_client.chat.completions.create(
            model="llama3-70b-8192",
            messages=[{"role": "user", "content": input_prompt}]
        )
        content = response.choices[0].message.content.strip()

    elif llm == "gemini":
        response = gemini_model.generate_content(input_prompt)
        content = response.text.strip()
    else:
        return {"error": "Unsupported LLM"}

    return {
        "functionalities": extract_section(content, "FUNCTIONALITIES"),
        "events": extract_section(content, "EVENTS"),
        "decisions": extract_section(content, "DECISIONS"),
        "dot_code": extract_dot_code(content)
    }

def generate_fused_cfg(user_input):
    dot_codes = {}
    for llm in ["openai", "groq", "gemini"]:
        result = fetch_llm_response(llm, user_input)
        dot_codes[llm] = result["dot_code"]
        store_dot_in_faiss(result["dot_code"])

    similar_dots = search_similar_dot(user_input)
    retrieved_snippets = "\n\n".join(similar_dots)

    fusion_prompt = (
    "You are an expert in generating Control Flow Graphs (CFGs).\n"
    "Here are some previously stored similar DOT codes:\n"
    f"{retrieved_snippets}\n\n"
    "Now here are DOTs from different LLMs for the given scenario:\n"
    f"Scenario: {user_input}\n\n"
    f"DOT from OpenAI: {dot_codes['openai']}\n"
    f"DOT from Llama3: {dot_codes['groq']}\n"
    f"DOT from Gemini: {dot_codes['gemini']}\n\n"
    "Analyze these DOT codes, identify commonalities and differences, and generate a new, improved DOT code that incorporates the best features of all the graphs,irrelavant nodes and edges should not come with resepect to scenario. The final cfg graph should be one component only."
    )

    response = client.chat.completions.create(
        model="gpt-3.5-turbo",
        messages=[{"role": "system", "content": "You are a skilled software engineering assistant."},
                  {"role": "user", "content": fusion_prompt}]
    )
    fusion_output = response.choices[0].message.content.strip()
    return extract_dot_code(fusion_output)

# --- Flask Routes ---
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/generate', methods=['POST'])
def generate_cfg_route():
    user_input = request.form['user_input']
    llm_choice = request.form['llm_choice']

    try:
        result = fetch_llm_response(llm_choice, user_input)
        dot_code = fix_invalid_dot_edges(result["dot_code"])

        with open("cfg_graph.dot", "w") as f:
            f.write(dot_code)

        metrics = calculate_cyclomatic_complexity(dot_code)
        os.system("dot -Tpng cfg_graph.dot -o static/cfg_graph.png")
        cfg_image = url_for('static', filename='cfg_graph.png')

        store_dot_in_faiss(dot_code)
        #similar_dots = search_similar_dot(dot_code)

        return render_template(
            'index.html',
            user_input=user_input,
            llm_choice=llm_choice,
            cfg_image=cfg_image,
            metrics=metrics,
            functionalities=result["functionalities"],
            events=result["events"],
            decisions=result["decisions"],
            similar_dots=similar_dots
        )
    except Exception as e:
        return render_template('index.html', error=str(e), user_input=user_input)

@app.route('/fuse_results', methods=['POST'])
def fuse_results():
    user_input = request.form['user_input']

    try:
        fused_dot_code = generate_fused_cfg(user_input)
        fused_dot_code = fix_invalid_dot_edges(fused_dot_code)

        with open("cfg_graph.dot", "w") as f:
            f.write(fused_dot_code)

        metrics = calculate_cyclomatic_complexity(fused_dot_code)
        os.system("dot -Tpng cfg_graph.dot -o static/cfg_graph.png")
        cfg_image = url_for('static', filename='cfg_graph.png')

        store_dot_in_faiss(fused_dot_code)
        similar_dots = search_similar_dot(fused_dot_code)

        return render_template(
            'index.html',
            user_input=user_input,
            llm_choice="fusion",
            cfg_image=cfg_image,
            metrics=metrics,
            similar_dots=similar_dots
        )
    except Exception as e:
        return render_template('index.html', error=str(e), user_input=user_input)

if __name__ == '__main__':
    app.run(debug=True)
